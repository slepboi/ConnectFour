/** The YellowPlayer : Subclass of Player */
public class YellowPlayer extends Player {
    
    /** Constructor for Yellow Player
     * @param name - player name
    */   
    public YellowPlayer(String name) {
        super(name,1);
    }
    
}